const t="http://localhost:8000",o="http://localhost:8080";export{o as B,t as D};
//# sourceMappingURL=env-vZH1dx0b.js.map
